//
//  BosccStudent.swift
//  boscc
//
//  Created by Hayden Shelton on 4/26/15.
//  Copyright (c) 2015 u0658884. All rights reserved.
//

import Foundation

class BosccStudent
{
    var uid: String?
    var major: String?
    var loggedIn: Bool = false
    var uname: String?
    init()
    {
        
    }
    
    
    
}