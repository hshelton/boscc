//
//  StudentDataModel.swift
//  boscc
//
//  Created by Hayden Shelton on 4/17/15.
//  Copyright (c) 2015 u0658884. All rights reserved.
//

import Foundation




class StudentDataModel
{
    
    
    init()
    {
        //make server call
        
        
    }
    
 
    
    
    
}