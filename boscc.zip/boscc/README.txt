Readme:

If you're having trouble registering with the onscreen keyboard, try hitting the return button on it to hide it. I didn't have time to fix this issue. 

Things work best for the CS major. I ran out of time while entering data for the other majors.

Please let me know once this has been graded, so I can turn off my Azure instance to save money.

Thanks.